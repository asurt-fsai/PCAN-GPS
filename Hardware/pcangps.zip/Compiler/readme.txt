It is recommended that you uninstall previous versions
of YAGARTO, before installing a new version of YAGARTO.

The NSIS installer of this version had a problem if your 
path is longer than 8192 characters. In this case it could 
be possible that your path will be corrupted.