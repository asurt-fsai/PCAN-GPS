===============================================================================
ReadMe.txt

PEAK-System Development Tools and Information for the PCAN-GPS

� 2014 PEAK-System Technik GmbH Darmstadt, Germany
===============================================================================


Contents
--------
  * Introduction
  * System Requirements
  * Package Contents
  * Contacting PEAK-System


Introduction
------------
This package enables you to develop application-specific firmware for
the PCAN-GPS by PEAK-System.


System Requirements
-------------------
- A development PC based on Windows 8.1, 7, Vista (32/64-bit)
- A CAN interface of the PCAN series to upload the firmware to your PCAN-GPS


Package Contents
----------------
LiesMich.txt
    This text file in German.

ReadMe.txt
    This text file.

Compiler\
    Installation programs of the Yagarto GNU ARM toolchain to compile your
    firmware.

Examples\
    Firmware examples that can be compiled with Yagarto.
    
PCAN-Flash\
    Windows tool for uploading your firmware to the PCAN-GPS via a CAN bus.
    Copy the directory to your PC and start without further installation.


Contacting PEAK-System
----------------------
Do you have questions about installing and using the PCAN-GPS, or do you
need information about further products from PEAK-System? Please contact:

PEAK-System Technik GmbH
Otto-Roehm-Strasse 69
64293 Darmstadt
Germany

Phone: +49 (0)6151 8173-20
Fax:   +49 (0)6151 8173-29

support@peak-system.com
www.peak-system.com
