#ifndef _MAIN_H_
#define _MAIN_H_

/***************************************************************************//**
* @file		main.h
* @brief
* @version	1.0.0
* @date		18. July 2014
* @author	PEAK-SYSTEM TECHNIK
*
* Copyright (c): PEAK-SYSTEM TECHNIK GMBH, DARMSTADT
* *****************************************************************************/



void Timer_1000usec(void);
DWORD get_fattime (void);

#endif
