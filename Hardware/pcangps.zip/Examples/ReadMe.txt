=== Sources for Firmware Examples ===

Each subdirectory contains sources for a firmware example. If you want to
compile an example under Windows, you can use the provided Yagarto toolchain.
Respective installation files are located in the Compiler directory (can be
found in the directory above).

For details, please refer to the hardware's user manual.
