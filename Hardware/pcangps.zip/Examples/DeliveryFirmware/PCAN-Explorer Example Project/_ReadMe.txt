PCAN-GPS.peproj is an example project for use with the PCAN-Explorer 5.
It works in connection with the PCAN-GPS Delivery Firmware.
 