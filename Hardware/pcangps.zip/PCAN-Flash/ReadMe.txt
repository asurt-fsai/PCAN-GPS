===============================================================================
ReadMe.txt

PCAN-Flash
Copyright (c) 2015 PEAK-System Technik GmbH Darmstadt, Germany
All rights reserved.
===============================================================================

PCAN-Flash must be started from a data carrier which is also writable,
otherwise the program's configuration (PcanFlash.ini file) cannot be saved.
The program doesn't work properly if it is run from a DVD. This is reflected,
for example, by and error message when selecting a CAN connection.

Make sure that the PCAN-Flash directory is located on a local hard disk, for
example, (if necessary, copy it from DVD) and that there are write permissions
in the directory, and execute PCAN-Flash (PcanFlash.exe) from there.
